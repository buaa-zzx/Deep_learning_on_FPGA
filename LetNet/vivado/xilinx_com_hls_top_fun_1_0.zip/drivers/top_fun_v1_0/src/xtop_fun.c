// ==============================================================
// File generated on Wed Feb 24 17:46:30 +0800 2021
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xtop_fun.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XTop_fun_CfgInitialize(XTop_fun *InstancePtr, XTop_fun_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Ctrl_bus_BaseAddress = ConfigPtr->Ctrl_bus_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XTop_fun_Start(XTop_fun *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_fun_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XTOP_FUN_CTRL_BUS_ADDR_AP_CTRL) & 0x80;
    XTop_fun_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XTOP_FUN_CTRL_BUS_ADDR_AP_CTRL, Data | 0x01);
}

u32 XTop_fun_IsDone(XTop_fun *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_fun_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XTOP_FUN_CTRL_BUS_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XTop_fun_IsIdle(XTop_fun *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_fun_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XTOP_FUN_CTRL_BUS_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XTop_fun_IsReady(XTop_fun *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_fun_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XTOP_FUN_CTRL_BUS_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XTop_fun_EnableAutoRestart(XTop_fun *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_fun_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XTOP_FUN_CTRL_BUS_ADDR_AP_CTRL, 0x80);
}

void XTop_fun_DisableAutoRestart(XTop_fun *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_fun_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XTOP_FUN_CTRL_BUS_ADDR_AP_CTRL, 0);
}

void XTop_fun_Set_In_DRAM(XTop_fun *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_fun_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XTOP_FUN_CTRL_BUS_ADDR_IN_DRAM_DATA, Data);
}

u32 XTop_fun_Get_In_DRAM(XTop_fun *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_fun_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XTOP_FUN_CTRL_BUS_ADDR_IN_DRAM_DATA);
    return Data;
}

void XTop_fun_Set_W_DRAM(XTop_fun *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_fun_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XTOP_FUN_CTRL_BUS_ADDR_W_DRAM_DATA, Data);
}

u32 XTop_fun_Get_W_DRAM(XTop_fun *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_fun_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XTOP_FUN_CTRL_BUS_ADDR_W_DRAM_DATA);
    return Data;
}

void XTop_fun_Set_Out_DRAM(XTop_fun *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_fun_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XTOP_FUN_CTRL_BUS_ADDR_OUT_DRAM_DATA, Data);
}

u32 XTop_fun_Get_Out_DRAM(XTop_fun *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_fun_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XTOP_FUN_CTRL_BUS_ADDR_OUT_DRAM_DATA);
    return Data;
}

void XTop_fun_Set_Bias_DRAM(XTop_fun *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_fun_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XTOP_FUN_CTRL_BUS_ADDR_BIAS_DRAM_DATA, Data);
}

u32 XTop_fun_Get_Bias_DRAM(XTop_fun *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_fun_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XTOP_FUN_CTRL_BUS_ADDR_BIAS_DRAM_DATA);
    return Data;
}

void XTop_fun_Set_layer(XTop_fun *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_fun_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XTOP_FUN_CTRL_BUS_ADDR_LAYER_DATA, Data);
}

u32 XTop_fun_Get_layer(XTop_fun *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_fun_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XTOP_FUN_CTRL_BUS_ADDR_LAYER_DATA);
    return Data;
}

void XTop_fun_InterruptGlobalEnable(XTop_fun *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_fun_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XTOP_FUN_CTRL_BUS_ADDR_GIE, 1);
}

void XTop_fun_InterruptGlobalDisable(XTop_fun *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_fun_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XTOP_FUN_CTRL_BUS_ADDR_GIE, 0);
}

void XTop_fun_InterruptEnable(XTop_fun *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XTop_fun_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XTOP_FUN_CTRL_BUS_ADDR_IER);
    XTop_fun_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XTOP_FUN_CTRL_BUS_ADDR_IER, Register | Mask);
}

void XTop_fun_InterruptDisable(XTop_fun *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XTop_fun_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XTOP_FUN_CTRL_BUS_ADDR_IER);
    XTop_fun_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XTOP_FUN_CTRL_BUS_ADDR_IER, Register & (~Mask));
}

void XTop_fun_InterruptClear(XTop_fun *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_fun_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XTOP_FUN_CTRL_BUS_ADDR_ISR, Mask);
}

u32 XTop_fun_InterruptGetEnabled(XTop_fun *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XTop_fun_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XTOP_FUN_CTRL_BUS_ADDR_IER);
}

u32 XTop_fun_InterruptGetStatus(XTop_fun *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XTop_fun_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XTOP_FUN_CTRL_BUS_ADDR_ISR);
}

