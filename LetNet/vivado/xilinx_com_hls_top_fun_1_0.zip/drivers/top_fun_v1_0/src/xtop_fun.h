// ==============================================================
// File generated on Wed Feb 24 17:46:30 +0800 2021
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XTOP_FUN_H
#define XTOP_FUN_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xtop_fun_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Ctrl_bus_BaseAddress;
} XTop_fun_Config;
#endif

typedef struct {
    u32 Ctrl_bus_BaseAddress;
    u32 IsReady;
} XTop_fun;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XTop_fun_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XTop_fun_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XTop_fun_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XTop_fun_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XTop_fun_Initialize(XTop_fun *InstancePtr, u16 DeviceId);
XTop_fun_Config* XTop_fun_LookupConfig(u16 DeviceId);
int XTop_fun_CfgInitialize(XTop_fun *InstancePtr, XTop_fun_Config *ConfigPtr);
#else
int XTop_fun_Initialize(XTop_fun *InstancePtr, const char* InstanceName);
int XTop_fun_Release(XTop_fun *InstancePtr);
#endif

void XTop_fun_Start(XTop_fun *InstancePtr);
u32 XTop_fun_IsDone(XTop_fun *InstancePtr);
u32 XTop_fun_IsIdle(XTop_fun *InstancePtr);
u32 XTop_fun_IsReady(XTop_fun *InstancePtr);
void XTop_fun_EnableAutoRestart(XTop_fun *InstancePtr);
void XTop_fun_DisableAutoRestart(XTop_fun *InstancePtr);

void XTop_fun_Set_In_DRAM(XTop_fun *InstancePtr, u32 Data);
u32 XTop_fun_Get_In_DRAM(XTop_fun *InstancePtr);
void XTop_fun_Set_W_DRAM(XTop_fun *InstancePtr, u32 Data);
u32 XTop_fun_Get_W_DRAM(XTop_fun *InstancePtr);
void XTop_fun_Set_Out_DRAM(XTop_fun *InstancePtr, u32 Data);
u32 XTop_fun_Get_Out_DRAM(XTop_fun *InstancePtr);
void XTop_fun_Set_Bias_DRAM(XTop_fun *InstancePtr, u32 Data);
u32 XTop_fun_Get_Bias_DRAM(XTop_fun *InstancePtr);
void XTop_fun_Set_layer(XTop_fun *InstancePtr, u32 Data);
u32 XTop_fun_Get_layer(XTop_fun *InstancePtr);

void XTop_fun_InterruptGlobalEnable(XTop_fun *InstancePtr);
void XTop_fun_InterruptGlobalDisable(XTop_fun *InstancePtr);
void XTop_fun_InterruptEnable(XTop_fun *InstancePtr, u32 Mask);
void XTop_fun_InterruptDisable(XTop_fun *InstancePtr, u32 Mask);
void XTop_fun_InterruptClear(XTop_fun *InstancePtr, u32 Mask);
u32 XTop_fun_InterruptGetEnabled(XTop_fun *InstancePtr);
u32 XTop_fun_InterruptGetStatus(XTop_fun *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
